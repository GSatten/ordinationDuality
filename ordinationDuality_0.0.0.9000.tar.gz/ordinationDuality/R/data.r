#' Tobacco data for ordinationDuality package
#'
#' @docType data
#'
#' @usage load(tobacco)
#'
#' @format phyloseq file with otu.table, tax.table, phylogenetic tree.
#'
#' @references Tyx et al. PloS One 2016 
#'
#' @examples data=load(tobacco)
#'           otu.table=tobacco$otu.table
#'           tax.table=tobacco$tax.table
#'           dist=tobacco$dist
#'           sample.names=tobacco$sample.names
"tobacco"