#' unconstrained.reg
#'
#' this function gives the unconstrained regression solution described in Satten et al. PloS One.  it is included for completeness and is not recommended for use.
#'
#' @param x the data matrix.
#'
#' @param b a matrix with orthonormal columns having the same number of rows as x; typically the matrix of eigenvectors of a distance matrix.
#'
#' @param tol.d threshold for deciding if diagonal elements of D are 0; values <=tol.d are set to zero.  default value is 10^-8 .
#'
#' @return v, a matrix having orthonormal columns that give the directions of the (OTU) loadings in feature space. 
#'
#' @return d, a vector vector with the diagonal elements of the matrix D.
#'
#' @return d.inv, a vector with the diagonal elements of the matrix D^-1
#'
#' @return z, the matrix V.D^-1
#'
#' @return b.hat, a matrix having columns which are estimates of b. 
#'
#' @return x, the original data matrix x used in the call to unconstrained.reg .
#'
#' @return b, the original b matrix used in the call to unconstrained.reg .
#'
#' @keywords: unconstrained regression orthogonal decomposition.
#'
#' @export
#'
#' @examples res=unconstrained.reg(x=data.matrix, b=b.reduced)
#'
unconstrained.reg = function( x, b, tol.d=10^-8 ) {
  if (dim(x)[1] != dim(b)[1]) x=t(x)
  if (dim(x)[1] != dim(b)[1]) stop( 'error in dimension of x or b' )
  n.var=dim(b)[2]
  x.svd=svd(x)
  nonzero=(x.svd$d>tol.d)
  s.inv=rep(0,length(x.svd$d))
  p.r=s.inv
  s.inv[nonzero]=1/x.svd$d[nonzero]
  p.r[nonzero]=1
  x.ginv=x.svd$v %*% diag(s.inv) %*% t(x.svd$u)
  z= x.ginv%*% b
  d.inv=sqrt( colSums(z^2) ) 
  v=scale(z, center=FALSE, scale=d.inv)
  use=(d.inv>tol.d)
  d=rep(0,length(d.inv))
  d[use]=1/d.inv[use]
  x.proj=x.svd$u %*% diag(p.r) %*% t(x.svd$u)
  b.hat=x.proj %*% b
  out=list(z,d,v,b.hat,x,b,d.inv)
  names(out)=list('z','d','v','b.hat','x','b','d.inv')
  return(out)
  }

  
#' unconstrained.decomp
#'
#' this function gives the unconstrained decomposition solution described in Satten et al. PloS One.  it is included for completeness and is not recommended for use.
#'
#' @param x the data matrix.
#'
#' @param b a matrix with orthonormal columns having the same number of rows as x; typically the matrix of eigenvectors of a distance matrix.
#'
#' @return v, a matrix having orthonormal columns that give the directions of the (OTU) loadings in feature space. 
#'
#' @return d, a vector vector with the diagonal elements of the matrix D.
#'
#' @return w, the matrix V.D
#'
#' @return b.hat, a matrix having columns which are estimates of b. 
#'
#' @return x, the original data matrix x used in the call to unconstrained.reg .
#'
#' @return b, the original b matrix used in the call to unconstrained.reg .
#'
#' @keywords: unconstrained orthogonal decomposition.
#'
#' @export
#'
#' @examples res=unconstrained.decomp(x=data.matrix, b=b.reduced)
#'
unconstrained.decomp = function( x, b ) {
  if (dim(x)[1] != dim(b)[1]) x=t(x)
  if (dim(x)[1] != dim(b)[1]) stop( 'error in dimension of x or b' )
  w=t(x) %*% b
  d=sqrt( colSums( w^2 ) )
  v=scale(w, center=FALSE, scale=d )
  b.hat=x %*% v  
  out=list(w,d,v,b.hat,x,b)
  names(out)=list('w','d','v','b.hat','x','b')
  return(out)
  }
  
