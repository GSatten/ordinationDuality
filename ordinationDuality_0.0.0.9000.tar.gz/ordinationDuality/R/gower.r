#' gower
#'
#' this function applies Gower's 1966 centering to the distance (or dissimilarity) matrix and then calculates its spectral decomposition.
#'
#' @param d a distance or dissimilarity matrix.  gower will convert d to a matrix if it is a distance object.
#'
#' @param square should the elements of the matrix d be squared before centering and spectral decomposition?  default is TRUE .
#'
#' @param eps eigenvectors with eigenvalue < eps are included in b, but are excluded from b.reduced.  default is 10^-8 .
#'
#' @return a, the distance matrix as scaled and centered by Gower 1966.
#'
#' @return b, the matrix whose columns are the eigenvectors of a (in decreasing order of eigenvalue).
#'
#' @return e, the vector of eigenvalues of a.
#'
#' @return b.reduced, the matrix whose columns are the eigenvectors of a excluding those for which abs(e)< eps .
#'
#' @keywords: gower distance dissimilarity matrix.
#'
#' @export
#'
#' @examples gow=gower(d=data.dist)
#'
gower = function (d, square = TRUE, eps = 10^-8) 
{
    d <- as.matrix(d)
    if (square) 
        d <- d^2
    n <- dim(d)[[1]]
    a <- mat.or.vec(n, n)
    rs <- rowMeans(d)
    cs <- colMeans(d)
    totmean <- mean(cs)
    a <- d
    for (i in 1:n) {
        a[i, ] <- a[i, ] - rs[[i]]
        a[, i] <- a[, i] - cs[[i]]
    }
    a <- -0.5 * (a + totmean)
    es <- eigen(a)
    b <- es$vectors
    e <- es$values
    zero.cols <- which(abs(es$values) < eps)
    include <- setdiff(1:n, zero.cols)
    b.reduced <- b[, include]
    out <- list(a = a, b = b, b.reduced = b.reduced, e = e)
    return(out)
}
