#' biplotQuantities
#'
#' Calculates various quantities needed to calculate biplots or describe the decomposition the total sum of squares ||x||^2 for data matrix x.
#'
#' @param res the output of ortho.decomp e.g. res=ortho.decomp(x,b) .
#'
#' @param n.vec.use the number of components used to calculate the biplot quantities or the contributions to the total sum of squares.  default is 2; maximum is the number of columns of b from the call to ortho.decomp .
#'
#' @param use which components should be used.  Default is the first n.vec.use components, but, for example, the 2nd and 3rd components could be used if use=c(2,3).
#'
#' @return otu.coords, the matrix having columns which are the n.vec.use-dimensional coordinates for each feature (OTU).
#'
#' @return otu.score, the vector having the norm of the columns of otu.coords, a measure of the contribution of the OTU to the sum of squares.
#'
#' @return otu.order, a list of the column numbers of the OTUs in decreasing order of their otu.score (data matrix passed from ortho.decomp always has OTUs as columns).
#'
#' @return top.otus, a list of OTU names (as given by the column names of x) in decreasing order of OTU score.
#'
#' @return otu.coords.ordered, sorted version of otu.coords where the columns appear in decreasing order of OTU score.
#'
#' @return component.score, the contribution of each component to the sum of squares (i.e., values of D^2).  note that component scores for all components are given even if n.vec.used is smaller than the number of columns of b.  
#' The order is given by the columns of b (i.e., by the eigenvalues of the distance matrix).
#'
#' @return component.order, a list of the components in decreasing order of their component score.
#'
#' @return ss.total, the total sum of squares for the data matrix x.
#'
#' @return ss.model, the sum of squares for the n.vec.use-dimensional approximation to x.
#'
#' @return ss.resid, the residual sum of squares.
#'
#' @keywords: biplot 
#'
#' @export
#'
#' @examples biplotQuantities(res, n.vec.use=3, use=c(1,3,4) )
biplotQuantities = function (res, n.vec.use = 2, use = 1:n.vec.use) 
{
    x <- res$x
    b <- res$b
    n.vec.use <- length(use)
    if (dim(x)[1] != dim(b)[1]) 
        x <- t(x)
    v <- res$v
    d <- res$d
    b.hat <- res$b.hat
    x.hat <- t(t(b[, use]) * d[use])
    x.hat <- x.hat %*% t(v[, use])
    wt <- d * t(v)
    w <- t(wt)
    otu.coords <- w[, use, drop=FALSE]
    otu.score <- rowSums(otu.coords^2)
    otu.order <- order(otu.score, decreasing = TRUE)
    otu.coords.ordered <- w[otu.order, use, drop=FALSE]
    top.otus <- colnames(x)[otu.order]
    component.score <- d^2
    component.order <- order(component.score)
    r.sq <- rep(0, n.vec.use)
    for (i in use) {
        r.sq[i] <- cor(b.hat[, i], b[, i])^2
    }
    ss.total <- sum(x^2)
    ss.model <- sum(x.hat^2)
    ss.resid <- sum((x - x.hat)^2)
    out <- list(otu.coords = otu.coords, otu.coords.ordered = otu.coords.ordered, 
        otu.score = otu.score, otu.order = otu.order, top.otus = top.otus, 
        component.score = component.score, component.order = component.order, 
        ss.total = ss.total, ss.resid = ss.resid, ss.model = ss.model, 
        r.sq = r.sq, x.hat = x.hat)
    return(out)
}

