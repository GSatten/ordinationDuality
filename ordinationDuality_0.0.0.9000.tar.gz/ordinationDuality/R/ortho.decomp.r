#' ortho.decomp
#'
#' This function finds the matrix V with orthogonal rows and diagonal matrix D with positive entries that minimizes ||x - b D V'||^2
#'
#' @param x the data matrix.
#'
#' @param b a matrix with orthonormal columns having the same number of rows as x; typically the matrix of eigenvectors of a distance matrix.
#'
#' @param tol.x threshold for deciding if singular values of x are 0; values <= tol.x are set to zero.  default value is 10^-8 .
#'
#' @param tol.d threshold for deciding if diagonal elements of D are 0; values <=tol.d are set to zero.  default value is 10^-8 .
#'
#' @param tol.conv threshold for convergence; algorithm iterates until the absolute value of the largest change (element-wise) in x^=b D^ V^' is <=tol.conv .  Default is 10^-8 .
#'
#' @param n.iter.max maximum number of iterations; default value is 1000.
#'
#' @param verbose if TRUE, prints number of iterations, whether convergence occurred, and final difference if no convergence.  default is TRUE.
#'
#' @param x.svd allows the user to pass the singular value decomposition of x; useful for repeated evaluations using the same x.  default is NULL (in which case SVD of x is calculated).
#'
#' @return v, a matrix having orthonormal columns that give the directions of the (OTU) loadings in feature space. 
#'
#' @return d, a vector vector with the diagonal elements of the matrix D in the orthogonal decomposition.
#'
#' @return b.hat, a matrix having columns which are estimates of b. 
#'
#' @return x.hat, a matrix that is the orthogonal decomposition approximation to the data matrix x.
#'
#' @return n.iter, the number of iterations used to converge.
#'
#' @return fail, equals 0 if the algorithm converged to the desired tolerance of 1 if not.
#'
#' @return x, the original data matrix x used in the call to ortho.decomp (possibly transposed if x in call had OTUs as rows).
#'
#' @return b, the original b matrix used in the call to ortho.decomp .
#'
#' keywords: orthogonal decomposition.
#'
#' @export
#'
#' @examples res=ortho.decomp(x=data.matrix, b=gower$b.reduced)

ortho.decomp = function (x, b, tol.x = 10^-8, tol.d=tol.x, tol.conv=tol.x, n.iter.max = 1000, verbose=TRUE, x.svd=NULL) 
{
    if (dim(x)[1] != dim(b)[1]) 
        x <- t(x)
    if (dim(x)[1] != dim(b)[1]) 
       stop( 'mismatch of dimension between x and b; exiting early' )
    n.obs <- dim(x)[1]
    n.otu <- dim(x)[2]
    n.vec <- dim(b)[2]
    if (n.otu>n.obs) {
       x.orig=x
       if (is.null(x.svd)) x.svd=svd(x)
       use.x=( abs(x.svd$d)>tol.x ) 
       x=t( x.svd$d[use.x]*t(x.svd$u[,use.x]) )
       n.otu=dim(x)[2]
       dim.reduction=TRUE
       }
    r2 <- rep(0, n.vec)
    d <- rep(1, n.vec)
    diff <- 1
    v <- mat.or.vec(n.otu, n.vec)
    n.iter <- 0
    fail <- 0
    xtb <- t(x) %*% b
    x.hat <- x
    while ((diff > tol.conv) & (n.iter <= n.iter.max)) {
        temp <- t(t(xtb) * d)
        temp.svd <- svd(temp)
        use <- abs(temp.svd$d) > tol.d
        new.v <- temp.svd$u[, use] %*% t(temp.svd$v[, use])
        new.d <- colSums(xtb * new.v)
        sign.flip <- (new.d < 0)
        new.v[, sign.flip] <- -new.v[, sign.flip]
        new.d <- abs(new.d)
        new.x.hat <- t(t(b) * new.d)
        new.x.hat <- new.x.hat %*% t(new.v)
        diff <- max(abs(new.x.hat - x.hat))
        v <- new.v
        d <- new.d
        x.hat <- new.x.hat
        n.iter <- n.iter + 1
        if (n.iter > n.iter.max) 
            fail <- 1
    }
    dinv <- rep(0,n.vec)
    use.d=(abs(d)>tol.d)
    dinv[use.d]=1/d[use.d]
    b.hat <- x %*% v
    b.hat <- t(t(b.hat) * dinv)
    for (k in 1:n.vec) r2[k] <- sum(b[, k] * b.hat[, k])/sum(b.hat[, 
        k]^2)
    if (dim.reduction) {
       v=x.svd$v[,use.x] %*% v    
       x.hat=x.hat %*% t(x.svd$v[,use.x])
       x=x.orig
       }
    msg=ifelse( fail==0, paste("ortho.decomp converged in ",n.iter," iterations"), paste("ortho.decomp failed to converge; final difference is ",diff))
    res <- list(v = v, d = d, b.hat = b.hat, r2 = r2, n.iter = n.iter, 
        x.hat = x.hat, fail = fail, x = x, b = b, diff = diff, 
        converge = msg)
    if (verbose) {
       cat(sprintf("%s\n", msg))
       }
    return(res)
}


